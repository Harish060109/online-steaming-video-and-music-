# StreamBox — Free Streaming App Prototype

A Flutter Android prototype for a college project demonstrating a Spotify/Netflix-style streaming experience using legally usable demo streams.

## Included
- Home screen
- Movie/video streaming
- Music/audio streaming
- Search
- Favorites/library
- Profile screen
- Dark UI
- Responsive Material 3 interface

## Important
This project is a **prototype**. It does not contain Spotify/Netflix copyrighted content, account credentials, DRM bypasses, or extracted streams.

The demo video/audio URLs are only placeholders for testing. For a real deployment, replace them with media that you own or are licensed to distribute.

## Requirements
- Flutter 3.x
- Android Studio or VS Code
- Android SDK
- Internet connection for `flutter pub get` and demo streams

## Run

If you already have Flutter installed:

```bash
flutter create .
flutter pub get
flutter run
```

For Android:

```bash
flutter build apk --release
```

The APK will normally be generated under:

`build/app/outputs/flutter-apk/app-release.apk`

## Project structure

```text
streambox/
├── lib/
│   └── main.dart
├── pubspec.yaml
└── README.md
```

## Next development steps
1. Add Firebase Authentication.
2. Add Firestore for users, playlists, favorites and history.
3. Add Firebase Storage or a licensed media CDN.
4. Create an admin dashboard for uploading media.
5. Add categories, artists, albums and movie metadata.
6. Add subscriptions/ads only if legally appropriate.
7. Add proper backend authorization and signed media URLs.
8. Add offline playback only for media you are authorized to distribute.

## Suggested final architecture

Flutter Android app
        |
        v
REST API / Firebase
   |         |        |
Users    Catalog    Media Storage
   |
Favorites / Playlists / History
