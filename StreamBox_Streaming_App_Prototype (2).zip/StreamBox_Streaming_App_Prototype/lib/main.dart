import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:just_audio/just_audio.dart';

void main() => runApp(const StreamBoxApp());

class StreamBoxApp extends StatelessWidget {
  const StreamBoxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'StreamBox',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0B0D12),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF8B5CF6),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const HomeShell(),
    );
  }
}

class MediaItem {
  final String title;
  final String subtitle;
  final String category;
  final IconData icon;
  final Color color;
  final String? videoUrl;
  final String? audioUrl;

  const MediaItem({
    required this.title,
    required this.subtitle,
    required this.category,
    required this.icon,
    required this.color,
    this.videoUrl,
    this.audioUrl,
  });
}

// Big Buck Bunny is used only as a publicly available demo stream.
// Replace this URL with media you own or are licensed to distribute.
const demoVideo =
    'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';

// Replace with a music URL you own or are licensed to stream.
const demoAudio =
    'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3';

const movies = [
  MediaItem(
    title: 'Big Buck Bunny',
    subtitle: 'Demo movie stream',
    category: 'Animation',
    icon: Icons.movie_creation_outlined,
    color: Color(0xFF7C3AED),
    videoUrl: demoVideo,
  ),
  MediaItem(
    title: 'Demo Cinema',
    subtitle: 'Replace with your licensed video',
    category: 'Movie',
    icon: Icons.local_movies_outlined,
    color: Color(0xFF2563EB),
    videoUrl: demoVideo,
  ),
  MediaItem(
    title: 'Campus Stories',
    subtitle: 'Your own campus video',
    category: 'College',
    icon: Icons.school_outlined,
    color: Color(0xFF059669),
    videoUrl: demoVideo,
  ),
];

const music = [
  MediaItem(
    title: 'Demo Track 01',
    subtitle: 'Streaming prototype',
    category: 'Music',
    icon: Icons.music_note,
    color: Color(0xFFDB2777),
    audioUrl: demoAudio,
  ),
  MediaItem(
    title: 'Demo Track 02',
    subtitle: 'Replace with licensed audio',
    category: 'Music',
    icon: Icons.album_outlined,
    color: Color(0xFFD97706),
    audioUrl: demoAudio,
  ),
];

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  final Set<String> favorites = {};

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(
        favorites: favorites,
        onFavorite: (item) => setState(() {
          favorites.contains(item.title)
              ? favorites.remove(item.title)
              : favorites.add(item.title);
        }),
      ),
      SearchPage(favorites: favorites),
      LibraryPage(favorites: favorites),
      const ProfilePage(),
    ];

    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Search'),
          NavigationDestination(icon: Icon(Icons.library_music_outlined), label: 'Library'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final Set<String> favorites;
  final void Function(MediaItem) onFavorite;

  const HomePage({super.key, required this.favorites, required this.onFavorite});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          sliver: SliverToBoxAdapter(
            child: Row(
              children: [
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('StreamBox', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800)),
                      SizedBox(height: 4),
                      Text('Your legal streaming prototype', style: TextStyle(color: Colors.white60)),
                    ],
                  ),
                ),
                CircleAvatar(
                  backgroundColor: Color(0xFF27212F),
                  child: Icon(Icons.person),
                )
              ],
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.all(20),
          sliver: SliverToBoxAdapter(
            child: Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(24),
                gradient: const LinearGradient(colors: [Color(0xFF5B21B6), Color(0xFF1D4ED8)]),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Stream your own content', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text('Music + movies + playlists in one Android application.'),
                  SizedBox(height: 18),
                  Text('DEMO MODE', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                ],
              ),
            ),
          ),
        ),
        const SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverToBoxAdapter(child: Text('Movies', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold))),
        ),
        SliverToBoxAdapter(
          child: SizedBox(
            height: 220,
            child: ListView.separated(
              padding: const EdgeInsets.all(20),
              scrollDirection: Axis.horizontal,
              itemCount: movies.length,
              separatorBuilder: (_, __) => const SizedBox(width: 14),
              itemBuilder: (context, i) => MediaCard(
                item: movies[i],
                isFavorite: favorites.contains(movies[i].title),
                onFavorite: () => onFavorite(movies[i]),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VideoScreen(item: movies[i]))),
              ),
            ),
          ),
        ),
        const SliverPadding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          sliver: SliverToBoxAdapter(child: Text('Music', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold))),
        ),
        SliverList.builder(
          itemCount: music.length,
          itemBuilder: (context, i) => ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
            leading: CircleAvatar(
              radius: 27,
              backgroundColor: music[i].color,
              child: Icon(music[i].icon, color: Colors.white),
            ),
            title: Text(music[i].title, style: const TextStyle(fontWeight: FontWeight.w600)),
            subtitle: Text(music[i].subtitle),
            trailing: IconButton(
              icon: Icon(favorites.contains(music[i].title) ? Icons.favorite : Icons.favorite_border),
              onPressed: () => onFavorite(music[i]),
            ),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AudioScreen(item: music[i]))),
          ),
        ),
        const SliverToBoxAdapter(child: SizedBox(height: 30)),
      ],
    );
  }
}

class MediaCard extends StatelessWidget {
  final MediaItem item;
  final bool isFavorite;
  final VoidCallback onFavorite;
  final VoidCallback onTap;

  const MediaCard({
    super.key,
    required this.item,
    required this.isFavorite,
    required this.onFavorite,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 170,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [item.color, item.color.withOpacity(.35)],
                  ),
                ),
                child: Stack(
                  children: [
                    Center(child: Icon(item.icon, size: 62, color: Colors.white.withOpacity(.85))),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: IconButton.filledTonal(
                        onPressed: onFavorite,
                        icon: Icon(isFavorite ? Icons.favorite : Icons.favorite_border, size: 18),
                      ),
                    ),
                    const Positioned(
                      left: 10,
                      bottom: 10,
                      child: CircleAvatar(
                        radius: 18,
                        child: Icon(Icons.play_arrow),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
            Text(item.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

class SearchPage extends StatefulWidget {
  final Set<String> favorites;
  const SearchPage({super.key, required this.favorites});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  String query = '';

  List<MediaItem> get results {
    final all = [...movies, ...music];
    return all.where((x) => '${x.title} ${x.subtitle} ${x.category}'.toLowerCase().contains(query.toLowerCase())).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, 10),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text('Search', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: TextField(
            onChanged: (v) => setState(() => query = v),
            decoration: InputDecoration(
              hintText: 'Search movies, music, artists...',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: const Color(0xFF171A22),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.all(20),
            itemCount: results.length,
            itemBuilder: (context, i) {
              final item = results[i];
              return ListTile(
                leading: CircleAvatar(backgroundColor: item.color, child: Icon(item.icon)),
                title: Text(item.title),
                subtitle: Text('${item.category} • ${item.subtitle}'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => item.videoUrl != null ? VideoScreen(item: item) : AudioScreen(item: item),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class LibraryPage extends StatelessWidget {
  final Set<String> favorites;
  const LibraryPage({super.key, required this.favorites});

  @override
  Widget build(BuildContext context) {
    final items = [...movies, ...music].where((x) => favorites.contains(x.title)).toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Padding(
          padding: EdgeInsets.all(20),
          child: Text('Your Library', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        ),
        if (items.isEmpty)
          const Expanded(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.favorite_border, size: 60, color: Colors.white38),
                  SizedBox(height: 12),
                  Text('No favorites yet'),
                  Text('Tap the heart icon to save media.', style: TextStyle(color: Colors.white54)),
                ],
              ),
            ),
          )
        else
          Expanded(
            child: ListView.builder(
              itemCount: items.length,
              itemBuilder: (_, i) => ListTile(
                leading: CircleAvatar(backgroundColor: items[i].color, child: Icon(items[i].icon)),
                title: Text(items[i].title),
                subtitle: Text(items[i].category),
              ),
            ),
          ),
      ],
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const Text('Profile', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)),
        const SizedBox(height: 12),
        const Center(child: Text('Demo User', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        const Center(child: Text('student@streambox.local', style: TextStyle(color: Colors.white54))),
        const SizedBox(height: 30),
        Card(
          child: Column(
            children: const [
              ListTile(leading: Icon(Icons.download_outlined), title: Text('Downloads'), trailing: Icon(Icons.chevron_right)),
              ListTile(leading: Icon(Icons.history), title: Text('Watch history'), trailing: Icon(Icons.chevron_right)),
              ListTile(leading: Icon(Icons.settings_outlined), title: Text('Settings'), trailing: Icon(Icons.chevron_right)),
              ListTile(leading: Icon(Icons.info_outline), title: Text('About this project'), trailing: Icon(Icons.chevron_right)),
            ],
          ),
        ),
      ],
    );
  }
}

class VideoScreen extends StatefulWidget {
  final MediaItem item;
  const VideoScreen({super.key, required this.item});

  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  late VideoPlayerController controller;
  bool ready = false;

  @override
  void initState() {
    super.initState();
    controller = VideoPlayerController.networkUrl(Uri.parse(widget.item.videoUrl!))
      ..initialize().then((_) {
        if (mounted) setState(() => ready = true);
      });
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.item.title)),
      body: Column(
        children: [
          AspectRatio(
            aspectRatio: ready ? controller.value.aspectRatio : 16 / 9,
            child: ready
                ? VideoPlayer(controller)
                : const Center(child: CircularProgressIndicator()),
          ),
          if (ready)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  IconButton.filled(
                    onPressed: () => setState(() {
                      controller.value.isPlaying ? controller.pause() : controller.play();
                    }),
                    icon: Icon(controller.value.isPlaying ? Icons.pause : Icons.play_arrow),
                  ),
                  const SizedBox(width: 12),
                  Expanded(child: Text(widget.item.subtitle)),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class AudioScreen extends StatefulWidget {
  final MediaItem item;
  const AudioScreen({super.key, required this.item});

  @override
  State<AudioScreen> createState() => _AudioScreenState();
}

class _AudioScreenState extends State<AudioScreen> {
  final player = AudioPlayer();
  bool loading = true;
  bool playing = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      await player.setUrl(widget.item.audioUrl!);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.item.title)),
      body: Center(
        child: loading
            ? const CircularProgressIndicator()
            : Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CircleAvatar(
                      radius: 85,
                      backgroundColor: widget.item.color,
                      child: const Icon(Icons.music_note, size: 90),
                    ),
                    const SizedBox(height: 28),
                    Text(widget.item.title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
                    Text(widget.item.subtitle, style: const TextStyle(color: Colors.white54)),
                    const SizedBox(height: 30),
                    StreamBuilder<Duration>(
                      stream: player.positionStream,
                      builder: (_, snapshot) => Slider(
                        value: (snapshot.data ?? Duration.zero).inSeconds.toDouble().clamp(0, (player.duration ?? const Duration(seconds: 1)).inSeconds.toDouble()),
                        max: (player.duration ?? const Duration(seconds: 1)).inSeconds.toDouble(),
                        onChanged: (v) => player.seek(Duration(seconds: v.toInt())),
                      ),
                    ),
                    IconButton.filled(
                      iconSize: 38,
                      onPressed: () async {
                        if (player.playing) {
                          await player.pause();
                        } else {
                          await player.play();
                        }
                        if (mounted) setState(() => playing = player.playing);
                      },
                      icon: Icon(playing ? Icons.pause : Icons.play_arrow),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
